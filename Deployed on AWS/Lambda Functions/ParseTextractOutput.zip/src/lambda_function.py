import json

def lambda_handler(event, context):
    #print("received event: ", event)

    condensed_extract = {}

 
    for i in range(len(event['ExpenseDocuments'][0]['SummaryFields'])):
        key = event['ExpenseDocuments'][0]['SummaryFields'][i]['Type']['Text']
        value = event['ExpenseDocuments'][0]['SummaryFields'][i]['ValueDetection']['Text']
        
        if key not in condensed_extract.keys():
                condensed_extract[key] = value

        else:
            temp = " " + value
            condensed_extract[key] += temp
        
        if len(event['ExpenseDocuments'][0]['LineItemGroups'][0]['LineItems'])> 0:
            condensed_extract['items'] = {}
            for j in range(len(event['ExpenseDocuments'][0]['LineItemGroups'][0]['LineItems'][0]['LineItemExpenseFields'])):
                value = event['ExpenseDocuments'][0]['LineItemGroups'][0]['LineItems'][0]['LineItemExpenseFields'][j]['ValueDetection']['Text']
                condensed_extract['items']['item'+str(j)] = value
    
    
    return condensed_extract

