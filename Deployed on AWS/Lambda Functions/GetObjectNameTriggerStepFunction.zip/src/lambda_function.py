import json
import urllib.parse
import boto3

print('Loading function')

stepfunction_client = boto3.client('stepfunctions')

STEP_FUNCTION_ARN = "arn:aws:states:us-east-1:418295723137:stateMachine:MyStateMachine-sj5krp1uk"


def lambda_handler(event, context):

    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')

    try:
        print("in try loop")
        step_function_input = {
            "bucket": bucket,
            "key": key
        }
        
        # Trigger the Step Function
        response = stepfunction_client.start_execution(
            stateMachineArn=STEP_FUNCTION_ARN,
            input=json.dumps(step_function_input)
        )
        print("returned from step function")
        print(response)

    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
