import json
import psycopg2
import os
import datetime

def lambda_handler(event, context):
    
    db_host = os.getenv("DB_HOST")
    db_port = os.getenv("DB_PORT", 5432)
    db_user = os.getenv("DB_USER")
    db_password = os.getenv("DB_PASSWORD")
    db_name = os.getenv("DB_NAME")

    receipt_id = event['key']
    user_id = event['user_id']
    pred_amount = event["predicted_amount"]
    pred_date_str = event["predicted_date"]['full_date']
    pred_category = event['predicted_category']
    
    pred_date = datetime.datetime.strptime(pred_date_str, "%m/%d/%Y").date() if pred_date_str else None


    insert_query = """
    INSERT INTO receipt_pred (receipt_id, user_id, pred_amount, pred_date, pred_category)
    VALUES (%s, %s, %s, %s, %s)
    """
    
    connection = None
    try:
        # Connect to PostgreSQL database
        connection = psycopg2.connect(
            host=db_host,
            port=db_port,
            user=db_user,
            password=db_password,
            database = db_name
        )
        
        cursor = connection.cursor()

        # Execute the INSERT query
        cursor.execute(insert_query, (receipt_id, user_id, pred_amount, pred_date, pred_category))

        connection.commit()

        print(f"Successfully inserted receipt {receipt_id} for user {user_id} into receipt_pred")

    except Exception as e:
        print(f"Error: {e}")

    finally:
        if connection:
            connection.close()

    return event
